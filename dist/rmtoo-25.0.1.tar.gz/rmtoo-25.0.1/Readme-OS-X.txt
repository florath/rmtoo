
Please note that there is no official support for Mac OS X. 

Nevertheless there are users which reported to successfully use rmtoo
under Mac OS X.

Some hints:

o macports is needed

o sudo port install texlive-fontutils gnuplot

o sudo port install texlive


