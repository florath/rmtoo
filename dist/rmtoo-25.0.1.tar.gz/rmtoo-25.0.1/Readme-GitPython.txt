Starting with rmtoo version 11, git-python is shipped with rmtoo.  The
API of git-python is changing rapidly - there are currently three
different APIs out there.  As soon as the change rate settles, the
git-python will be removed from the package and the OS / distribution
version should be used. git-python home page is at
http://gitorious.org/git-python.

