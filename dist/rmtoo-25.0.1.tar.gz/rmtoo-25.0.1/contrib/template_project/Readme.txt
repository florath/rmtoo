This is a project template.

Just copy it over and start requirements management.



