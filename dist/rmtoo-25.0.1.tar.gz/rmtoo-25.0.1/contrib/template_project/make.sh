#!/bin/bash
source /etc/profile.d/R50*
make >make.log 2>&1
