rmtoo-gui
---------

Installes (additional) GUI on any rmtoo flavor.
