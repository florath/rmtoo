rmtoo-small
===========

Installs the small flavor of rmtoo.
