VMs
===

There is the possiblity to use predefined VMs for the evaluation of
rmtoo as well as for daily work.

Documentation
-------------

#. A list of different flavors of predefined VMs: ReadmeFlavors_.

#. For evaluation and running preinstalled VMs on Amazon AWS, check
   out ReadmeAWSStartVM_.

#. A detailed documentation and how to use the preinstalled VMs:
   ReadmePreinstalledVM_. 

.. _ReadmeFlavors: Readme-Flavors.rst

.. _ReadmeAWSStartVM: Readme-AWSStartVM.rst

.. _ReadmePreinstalledVM: Readme-PreinstalledVM.rst


