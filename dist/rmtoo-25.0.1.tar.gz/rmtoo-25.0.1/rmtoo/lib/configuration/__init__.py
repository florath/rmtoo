'__init__ of configuration module'
