../../bin/rmtoo-pricing-graph reqspricing.csv reqspricing.dot
dot -Tpng -o reqspricing.png reqspricing.dot
