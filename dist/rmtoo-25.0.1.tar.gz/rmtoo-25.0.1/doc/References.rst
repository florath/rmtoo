References of rmtoo
===================

Doorstop: Text-Based Requirements Management Using Version Control
------------------------------------------------------------------

One example is rmtoo [12], which is a pure command line interface with
dependency graph generation. This tool  uses  the  model  of  storing
requirements  as  text  files.  Unfortunately,  the  tool  is  not
specifically  designed  to support Windows and lacks a GUI interface,
which may deter less technical users.

http://file.scirp.org/pdf/JSEA_2014032713545074.pdf

Requirement Management
----------------------

Before starting any new project, we first gather requirements. Our
requirement management approach was inspired by rmtoo in terms of
storing data and relations.

http://www.idevelopernetwork.com/requirement-management/
